const bikes = ["Guntur", "Chilakaluripet", "Veluru"];

let text = "";
for (let x of bikes) {
  text += x + " ";
}

console.log(text);