var i=15;  
while (i<=15)  
{  
console.log(i);  
i++;  
}  