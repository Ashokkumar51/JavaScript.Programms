var i=15;  
do{  
console.log(i);  
i++;  
}while (i<=25);  