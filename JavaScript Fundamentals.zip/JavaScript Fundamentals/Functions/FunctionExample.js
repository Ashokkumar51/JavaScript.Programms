function sum(a,b){
    console.log(a + b);
}

var result = sum(1,5);