function add(){
    let a = 15;
    let b = 45;
    return a + b;
}

var a = add();
console.log(a);

