//1.	+ (Addition):

var x = 10;  
var y = 20;  
var z=x+y;  
console.log(z);

//2.	- (Subtraction):

var x = 10;  
var y = 20;  
var z=x-y;  
console.log(z);

//3.	* (Multiplication):

var x = 10;  
var y = 20;  
var z=x*y;  
console.log(z);

//4.	/ (Division):

var x = 10;  
var y = 20;  
var z=x/y;  
console.log(z);

//5.	% (Modulus):

var x = 10;  
var y = 20;  
var z=x%y;  
console.log(z);

//6.	++ (Increment):

var x = 10;  
var y = 20;  
var z=++x;
var a=++y;
console.log(z);
console.log(a);

//7.	-- (Decrement):

var x = 10;  
var y = 20;  
var z=--x;
var a=--y;
console.log(z);
console.log(a);