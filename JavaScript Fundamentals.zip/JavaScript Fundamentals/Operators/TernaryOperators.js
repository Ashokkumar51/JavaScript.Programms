let b = 15;
let c = 45;

(b<c) ? console.log("True") : console.log("False");