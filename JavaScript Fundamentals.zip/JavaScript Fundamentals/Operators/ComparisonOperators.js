// Relational Operators - (==,===,!=,<=,>=,<,>)

var a = 15;
var b = 51;
var c = 9;
if(a == c){
    console.log("a is equal to c");
}
else{
    console.log("a is not equal to c");
}

if(a<b){
    console.log("a is less than b");
}
else{
    console.log("a is greater than b");
}

if(b>a){
    console.log("b is greater than a");
}
else{
    console.log("b  is lessthan a");
}

if(a === b){
    console.log("a is equal to b and assign the value to tha a by b");
}

if(a!=b){
    console.log("a is not equal to b");
}