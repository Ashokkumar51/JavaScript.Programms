var i;  
var emp = new Array();  
emp[0] = "Ashok";  
emp[1] = "Sunnu";  
emp[2] = "Indu";
emp[3] = "Vamsi";
  
for (i=0;i<emp.length;i++){  
console.log(emp[i]);  
}  