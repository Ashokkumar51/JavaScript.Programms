var emp=["Ashok","Indu","Sunnu","Vamsi"];  
for (i=0;i<emp.length;i++){  
console.log(emp[i]);  
}  