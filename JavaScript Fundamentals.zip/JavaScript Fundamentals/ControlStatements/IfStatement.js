var a=15;  
if(a>9){  
console.log("value of a is greater than 5");  
}  