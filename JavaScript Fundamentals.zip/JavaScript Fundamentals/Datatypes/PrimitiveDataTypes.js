// Data Types in JavaScript

var string = "Ashok"; // It holds the string datatype
var num = 15; // It holds the number datatype
var bool = true; // It holds the boolean datatype
var notdefined = undefined; // It holds the undefined datatypes that is not defined the value
var value = null; // It holds the nothing null

console.log(string);
console.log(num);
console.log(bool);
console.log(notdefined);
console.log(value);