// Object Datatype
var emp = new Object();
emp.name = "Ashok";
emp.id = 15;
emp.location = "Guntur";

console.log(emp.id);
console.log(emp.name);
console.log(emp.location);

// Array Datatype
var arr = new Array(1,2,3,4,5);
console.log(arr);