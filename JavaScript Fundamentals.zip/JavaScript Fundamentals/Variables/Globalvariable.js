var data=200;//gloabal variable  
function a(){  
console.log(data);  
}  
function b(){  
console.log(data);  
}  
a();//calling JavaScript function  
b();  
